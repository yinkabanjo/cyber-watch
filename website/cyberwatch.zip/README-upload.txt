CYBER ATTACK WATCH — upload to sprintright.tech (one time only)
================================================================
1. In DirectAdmin > File Manager, open public_html/.
2. Upload the whole "cyberwatch" folder (index.html, data/, fonts/).
   (If you can only upload files, upload cyberwatch.zip and use
   "Extract" in File Manager, then delete the zip.)
3. Visit https://sprintright.tech/cyberwatch/ to check it loads.

UPDATES ARE AUTOMATIC
The page reads its data from the public GitHub repo yinkabanjo/cyber-watch,
which the Monday sweep updates. Nothing to upload after this.
The copy in cyberwatch/data/ is only a fallback if GitHub can't be reached.

Notes
- Self-contained page: no external scripts, fonts or trackers.
- Fonts are SIL Open Font License files (licences in fonts/).
- To link it from the main site, add a menu or footer link to /cyberwatch/.
